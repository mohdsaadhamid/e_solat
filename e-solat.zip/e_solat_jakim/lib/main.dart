import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'services/notification_service.dart';  // add this import
import 'models/prayer_data.dart';
import 'services/zone_service.dart';
import 'widgets/daily_view.dart';
import 'widgets/monthly_view.dart';
import 'widgets/zone_dropdown.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.initialize(); // Initialize notifications
  final prefs = await SharedPreferences.getInstance();
  final savedZone = prefs.getString('selected_zone') ?? ZoneService.zoneCodes.first;
  runApp(MyApp(initialZone: savedZone));
}

class MyApp extends StatelessWidget {
  final String initialZone;
  const MyApp({super.key, required this.initialZone});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => AppState(initialZone),
      child: MaterialApp(
        title: 'E-Solat Jakim',
        theme: ThemeData(primarySwatch: Colors.green),
        home: const MainScreen(),
        debugShowCheckedModeBanner: false,
      ),
    );
  }
}

class AppState extends ChangeNotifier {
  String selectedZone;
  MonthlyPrayerData? monthlyData;
  bool isLoading = false;
  String? errorMessage;

  // Store notification IDs to cancel later
  final List<int> _scheduledIds = [];

  AppState(this.selectedZone) {
    loadDataForZone(selectedZone);
  }

  Future<void> loadDataForZone(String zone) async {
    selectedZone = zone;
    isLoading = true;
    errorMessage = null;
    notifyListeners();

    // Cancel old notifications before loading new data
    await _cancelAllScheduled();

    final data = await ZoneService.loadMonthlyData(zone);
    if (data != null) {
      monthlyData = data;
      // Schedule notifications for today's prayers
      await _scheduleTodayPrayers(data);
    } else {
      monthlyData = null;
      errorMessage = 'Tiada data bulanan untuk zon ini. Sila muat turun terlebih dahulu.';
    }
    isLoading = false;
    notifyListeners();

    final prefs = await SharedPreferences.getInstance();
    prefs.setString('selected_zone', zone);
  }

  Future<void> downloadMonthlyData() async {
    isLoading = true;
    notifyListeners();
    final success = await ZoneService.fetchAndSaveMonthlyData(selectedZone);
    if (success) {
      await loadDataForZone(selectedZone);
      errorMessage = null;
    } else {
      errorMessage = 'Gagal memuat turun data. Sila cuba lagi.';
    }
    isLoading = false;
    notifyListeners();
  }

  /// Schedule notifications for today's prayers (10 minutes before each).
  Future<void> _scheduleTodayPrayers(MonthlyPrayerData data) async {
    final todayPrayer = ZoneService.getTodaysPrayer(data);
    if (todayPrayer == null) return;

    // Parse prayer times and convert to DateTime objects
    final prayerMap = {
      'Imsak': todayPrayer.imsak,
      'Subuh': todayPrayer.fajr,
      'Syuruk': todayPrayer.syuruk,
      'Zohor': todayPrayer.dhuhr,
      'Asar': todayPrayer.asr,
      'Maghrib': todayPrayer.maghrib,
      'Isyak': todayPrayer.isha,
    };

    int id = 0;
    for (var entry in prayerMap.entries) {
      final timeStr = entry.value;
      final prayerName = entry.key;
      // Parse time like "05:38:am" or "05:38:00"
      final DateTime? prayerTime = _parseTimeString(timeStr);
      if (prayerTime != null) {
        // Schedule 10 minutes before
        final notifyTime = prayerTime.subtract(const Duration(minutes: 10));
        // Only schedule if it's in the future
        final now = DateTime.now();
        if (notifyTime.isAfter(now)) {
          await NotificationService.scheduleNotification(
            id: id,
            title: 'Waktu Solat $prayerName',
            body: '10 minit lagi. Waktu: ${_formatTime(prayerTime)}',
            scheduledTime: notifyTime,
          );
          _scheduledIds.add(id);
          id++;
        }
      }
    }
  }

  /// Parse a time string like "05:38:am" or "05:38:00" (assumes date is today).
  DateTime? _parseTimeString(String timeStr) {
    try {
      // Remove extra spaces and convert to lowercase
      String clean = timeStr.trim().toLowerCase();
      // Replace 'am'/'pm' with AM/PM and remove any colon after?
      // We'll assume format is like "05:38:am" -> we can split and parse.
      // If it contains 'am' or 'pm', we need to handle 12-hour format.
      bool isPm = clean.contains('pm');
      clean = clean.replaceAll(RegExp(r'[ap]m'), '').trim();
      final parts = clean.split(':');
      if (parts.length < 2) return null;
      int hour = int.tryParse(parts[0]) ?? 0;
      int minute = int.tryParse(parts[1]) ?? 0;
      // Handle 12-hour to 24-hour
      if (isPm && hour != 12) hour += 12;
      if (!isPm && hour == 12) hour = 0;
      final now = DateTime.now();
      return DateTime(now.year, now.month, now.day, hour, minute);
    } catch (e) {
      return null;
    }
  }

  String _formatTime(DateTime time) {
    final hour = time.hour > 12 ? time.hour - 12 : time.hour;
    final minute = time.minute.toString().padLeft(2, '0');
    final ampm = time.hour >= 12 ? 'pm' : 'am';
    return '$hour:$minute$ampm';
  }

  Future<void> _cancelAllScheduled() async {
    for (int id in _scheduledIds) {
      await NotificationService.cancel(id);
    }
    _scheduledIds.clear();
  }

  @override
  void dispose() {
    _cancelAllScheduled();
    super.dispose();
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedTabIndex = 0; // 0 = Daily, 1 = Monthly

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('E-Solat Jakim'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(48.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextButton(
                onPressed: () => setState(() => _selectedTabIndex = 0),
                style: TextButton.styleFrom(
                  foregroundColor: _selectedTabIndex == 0 ? Colors.white : Colors.grey,
                  backgroundColor: _selectedTabIndex == 0 ? Colors.green : Colors.transparent,
                ),
                child: const Text('Harian'),
              ),
              const SizedBox(width: 16),
              TextButton(
                onPressed: () => setState(() => _selectedTabIndex = 1),
                style: TextButton.styleFrom(
                  foregroundColor: _selectedTabIndex == 1 ? Colors.white : Colors.grey,
                  backgroundColor: _selectedTabIndex == 1 ? Colors.green : Colors.transparent,
                ),
                child: const Text('Bulanan'),
              ),
            ],
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            ZoneDropdown(
              selectedZone: appState.selectedZone,
              onChanged: (newZone) async {
                await appState.loadDataForZone(newZone!);
              },
            ),
            const SizedBox(height: 12),
            if (appState.isLoading)
              const Expanded(child: Center(child: CircularProgressIndicator()))
            else if (appState.errorMessage != null)
              Expanded(
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.warning, size: 48, color: Colors.orange),
                      const SizedBox(height: 8),
                      Text(appState.errorMessage!),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () => appState.downloadMonthlyData(),
                        child: const Text('Muat Turun Data Bulanan'),
                      ),
                    ],
                  ),
                ),
              )
            else if (appState.monthlyData != null)
              Expanded(
                child: _selectedTabIndex == 0
                    ? DailyView(data: appState.monthlyData!)
                    : MonthlyView(data: appState.monthlyData!),
              )
            else
              Expanded(
                child: Center(child: Text('Sila muat turun data untuk zon ${appState.selectedZone}')),
              ),
          ],
        ),
      ),
    );
  }
}