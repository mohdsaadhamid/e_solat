import 'package:flutter/material.dart';
import '../models/prayer_data.dart';
import '../services/zone_service.dart';

class DailyView extends StatelessWidget {
  final MonthlyPrayerData data;

  const DailyView({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    final today = ZoneService.getTodaysPrayer(data);
    if (today == null) {
      return const Center(child: Text('Tiada data untuk hari ini.'));
    }

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              ZoneService.zoneDisplayNames[data.zone] ?? data.zone,//data.zone,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.green,),
            ),
            const SizedBox(height: 4),
            
            SizedBox(
                width: double.infinity, // Forces text to take available width
                child: Text(
                  '${today.day}, ${today.date}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 16, color: Colors.grey),
                ),
              ),
            const Divider(height: 24),
            _buildRow('Imsak', today.imsak),
            _buildRow('Subuh', today.fajr),
            _buildRow('Syuruk', today.syuruk),
            _buildRow('Zohor', today.dhuhr),
            _buildRow('Asar', today.asr),
            _buildRow('Maghrib', today.maghrib),
            _buildRow('Isyak', today.isha),
            const Divider(height: 24),
            const Spacer(),
            Center(
              child: Text(
                'Bersumber daripada data e-Solat',
                style: TextStyle(fontSize: 12, color: Colors.grey[600]),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRow(String label, String time) {
    final cleanedTime = time.replaceAll(RegExp(r'.{3}$'), '');//.replaceAll(':00', '');
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          Text(cleanedTime, style: const TextStyle(fontSize: 16, color: Colors.teal)),
        ],
      ),
    );
  }
}