package com.example.e_solat_jakim

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
