import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models/prayer_data.dart';
import 'services/zone_service.dart';
import 'services/notification_service.dart';
import 'widgets/daily_view.dart';
import 'widgets/monthly_view.dart';
import 'widgets/zone_dropdown.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.initialize();
  final prefs = await SharedPreferences.getInstance();
  final savedZone = prefs.getString('selected_zone') ?? ZoneService.zoneCodes.first;
  runApp(MyApp(initialZone: savedZone));
}

class MyApp extends StatelessWidget {
  final String initialZone;
  const MyApp({super.key, required this.initialZone});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => AppState(initialZone),
      child: MaterialApp(
        title: 'E-Solat Jakim',
        theme: ThemeData(primarySwatch: Colors.green),
        home: const MainScreen(),
        debugShowCheckedModeBanner: false,
      ),
    );
  }
}

class AppState extends ChangeNotifier {
  String selectedZone;
  MonthlyPrayerData? monthlyData;
  bool isLoading = false;
  String? errorMessage;

  final List<Timer> _timers = [];

  AppState(this.selectedZone) {
    loadDataForZone(selectedZone);
  }

  Future<void> loadDataForZone(String zone) async {
    _cancelAllTimers();
    isLoading = true;
    errorMessage = null;
    monthlyData = null;
    notifyListeners();

    try {
      final data = await ZoneService.loadMonthlyData(zone);
      if (data != null) {
        monthlyData = data;
        _scheduleTodayPrayers(data);
        errorMessage = null;
      } else {
        monthlyData = null;
        errorMessage = 'Tiada data bulanan untuk zon ini. Sila muat turun terlebih dahulu.';
      }
    } catch (e) {
      monthlyData = null;
      errorMessage = 'Ralat memuat data: $e';
      print('loadDataForZone error: $e');
    } finally {
      isLoading = false;
      notifyListeners();
    }

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('selected_zone', zone);
    selectedZone = zone;
  }

  Future<void> downloadMonthlyData() async {
    if (isLoading) return;
    isLoading = true;
    errorMessage = null;
    notifyListeners();

    bool success = false;
    try {
      success = await ZoneService.fetchAndSaveMonthlyData(selectedZone);
    } catch (e) {
      errorMessage = 'Gagal memuat turun data: $e';
      print('downloadMonthlyData error: $e');
    } finally {
      if (success) {
        await loadDataForZone(selectedZone);
      } else {
        if (errorMessage == null) {
          errorMessage = 'Gagal memuat turun data. Sila periksa sambungan internet.';
        }
        isLoading = false;
        notifyListeners();
      }
    }
  }

  Future<void> resetAllData() async {
  if (isLoading) return;
  // Show confirmation dialog (optional – we'll handle it in the UI)
  isLoading = true;
  errorMessage = null;
  notifyListeners();

  try {
    await ZoneService.deleteAllData();
    // Clear the current data
    monthlyData = null;
    // Reload the current zone – this will now show "no data" message
    await loadDataForZone(selectedZone);
  } catch (e) {
    errorMessage = 'Gagal memadam data: $e';
    isLoading = false;
    notifyListeners();
  }
  }

  void _cancelAllTimers() {
    for (var timer in _timers) {
      timer.cancel();
    }
    _timers.clear();
  }

  void _scheduleTodayPrayers(MonthlyPrayerData data) {
    final todayPrayer = ZoneService.getTodaysPrayer(data);
    if (todayPrayer == null) return;

    final prayerMap = {
      'Imsak': todayPrayer.imsak,
      'Subuh': todayPrayer.fajr,
      'Syuruk': todayPrayer.syuruk,
      'Zohor': todayPrayer.dhuhr,
      'Asar': todayPrayer.asr,
      'Maghrib': todayPrayer.maghrib,
      'Isyak': todayPrayer.isha,
    };

    int id = 0;
    for (var entry in prayerMap.entries) {
      final timeStr = entry.value;
      final prayerName = entry.key;
      final prayerTime = _parseTimeString(timeStr);
      if (prayerTime != null) {
        final now = DateTime.now();
        final notifyTime = prayerTime.subtract(const Duration(minutes: 10));
        if (notifyTime.isAfter(now)) {
          final duration = notifyTime.difference(now);
          final timer = Timer(duration, () {
            NotificationService.showNotification(
              id: id,
              title: 'Waktu Solat $prayerName',
              body: '10 minit lagi. Waktu: ${_formatTime(prayerTime)}',
            );
          });
          _timers.add(timer);
          id++;
        }
      }
    }
  }

  DateTime? _parseTimeString(String timeStr) {
    try {
      String clean = timeStr.trim().toLowerCase();
      bool isPm = clean.contains('pm');
      clean = clean.replaceAll(RegExp(r'[ap]m'), '').trim();
      final parts = clean.split(':');
      if (parts.length < 2) return null;
      int hour = int.tryParse(parts[0]) ?? 0;
      int minute = int.tryParse(parts[1]) ?? 0;
      if (isPm && hour != 12) hour += 12;
      if (!isPm && hour == 12) hour = 0;
      final now = DateTime.now();
      return DateTime(now.year, now.month, now.day, hour, minute);
    } catch (e) {
      return null;
    }
  }

  String _formatTime(DateTime time) {
    final hour = time.hour > 12 ? time.hour - 12 : time.hour;
    final minute = time.minute.toString().padLeft(2, '0');
    final ampm = time.hour >= 12 ? 'pm' : 'am';
    return '$hour:$minute$ampm';
  }

  @override
  void dispose() {
    _cancelAllTimers();
    super.dispose();
  }
}

// The rest of the file (MainScreen, etc.) remains unchanged.
class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedTabIndex = 0;

  void _showResetDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Padam Semua Data?'),
          content: const Text(
            'Tindakan ini akan memadamkan semua data solat yang telah dimuat turun. '
            'Anda perlu memuat turun semula untuk zon yang dipilih. '
            'Adakah anda pasti?'
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Batal'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                final appState = Provider.of<AppState>(context, listen: false);
                appState.resetAllData();
              },
              child: const Text('Padam'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('E-Solat Jakim'),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_forever),
            tooltip: 'Reset All Data',
            onPressed: () => _showResetDialog(context),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(48.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextButton(
                onPressed: () => setState(() => _selectedTabIndex = 0),
                style: TextButton.styleFrom(
                  foregroundColor: _selectedTabIndex == 0 ? Colors.white : Colors.grey,
                  backgroundColor: _selectedTabIndex == 0 ? Colors.green : Colors.transparent,
                ),
                child: const Text('Harian'),
              ),
              const SizedBox(width: 16),
              TextButton(
                onPressed: () => setState(() => _selectedTabIndex = 1),
                style: TextButton.styleFrom(
                  foregroundColor: _selectedTabIndex == 1 ? Colors.white : Colors.grey,
                  backgroundColor: _selectedTabIndex == 1 ? Colors.green : Colors.transparent,
                ),
                child: const Text('Bulanan'),
              ),
            ],
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            ZoneDropdown(
              selectedZone: appState.selectedZone,
              onChanged: (newZone) async {
                if (newZone != null && newZone != appState.selectedZone) {
                  await appState.loadDataForZone(newZone);
                }
              },
            ),
            const SizedBox(height: 12),
            if (appState.isLoading)
              const Expanded(child: Center(child: CircularProgressIndicator()))
            else if (appState.errorMessage != null)
              Expanded(
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.warning, size: 48, color: Colors.orange),
                      const SizedBox(height: 8),
                      Text(appState.errorMessage!),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () => appState.downloadMonthlyData(),
                        child: const Text('Muat Turun Data Bulanan'),
                      ),
                    ],
                  ),
                ),
              )
            else if (appState.monthlyData != null)
              Expanded(
                child: _selectedTabIndex == 0
                    ? DailyView(data: appState.monthlyData!)
                    : MonthlyView(data: appState.monthlyData!),
              )
            else
              Expanded(
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('Sila muat turun data untuk zon ${appState.selectedZone}'),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () => appState.downloadMonthlyData(),
                        child: const Text('Muat Turun Data Bulanan'),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}