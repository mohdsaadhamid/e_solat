import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  static Future<void> initialize() async {
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const linuxInit = LinuxInitializationSettings(
      defaultActionName: 'Open',
    );
    const initSettings = InitializationSettings(
      android: androidInit,
      linux: linuxInit,
    );
    await _plugin.initialize(initSettings);
  }

  static Future<void> showNotification({
    required int id,
    required String title,
    required String body,
    String? payload,
  }) async {
    const androidDetails = AndroidNotificationDetails(
      'prayer_channel',
      'Prayer Notifications',
      importance: Importance.max,
      priority: Priority.high,
    );
    const linuxDetails = LinuxNotificationDetails(
      category: LinuxNotificationCategory.email,
      actions: <LinuxNotificationAction>[
        LinuxNotificationAction(key: 'open', label: 'Open'),
      ],
    );
    const details = NotificationDetails(
      android: androidDetails,
      linux: linuxDetails,
    );
    await _plugin.show(id, title, body, details, payload: payload);
  }


  // services/zone_service.dart – add this method



  static Future<void> cancelAll() async {
    await _plugin.cancelAll();
  }
  
}

