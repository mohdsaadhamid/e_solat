class PrayerDay {
  final String hijri;
  final String date;
  final String day;
  final String imsak;
  final String fajr;
  final String syuruk;
  final String dhuhr;
  final String asr;
  final String maghrib;
  final String isha;

  PrayerDay.fromJson(Map<String, dynamic> json)
      : hijri = json['hijri'] ?? '',
        date = json['date'] ?? '',
        day = json['day'] ?? '',
        imsak = json['imsak'] ?? '',
        fajr = json['fajr'] ?? '',
        syuruk = json['syuruk'] ?? '',
        dhuhr = json['dhuhr'] ?? '',
        asr = json['asr'] ?? '',
        maghrib = json['maghrib'] ?? '',
        isha = json['isha'] ?? '';
}

class MonthlyPrayerData {
  final String zone;
  final String serverTime;
  final List<PrayerDay> days;

  MonthlyPrayerData({required this.zone, required this.serverTime, required this.days});

  factory MonthlyPrayerData.fromJson(Map<String, dynamic> json, String zone) {
    final list = (json['prayerTime'] as List)
        .map((item) => PrayerDay.fromJson(item))
        .toList();
    return MonthlyPrayerData(
      zone: zone,
      serverTime: json['serverTime'] ?? '',
      days: list,
    );
  }
}