// models/prayer_data.dart
class PrayerDay {
  final String hijri;
  final String date;
  final String day;
  final String imsak;
  final String fajr;
  final String syuruk;
  final String dhuhr;
  final String asr;
  final String maghrib;
  final String isha;

  PrayerDay.fromJson(Map<String, dynamic> json)
      : hijri = json['hijri'] ?? '',
        date = json['date'] ?? '',
        day = json['day'] ?? '',
        imsak = json['imsak'] ?? '',
        fajr = json['fajr'] ?? '',
        syuruk = json['syuruk'] ?? '',
        dhuhr = json['dhuhr'] ?? '',
        asr = json['asr'] ?? '',
        maghrib = json['maghrib'] ?? '',
        isha = json['isha'] ?? '';
}

class MonthlyPrayerData {
  final String zone;
  final String serverTime;
  final List<PrayerDay> days;
  final int month;
  final int year;

  MonthlyPrayerData({
    required this.zone,
    required this.serverTime,
    required this.days,
    required this.month,
    required this.year,
  });

  factory MonthlyPrayerData.fromJson(Map<String, dynamic> json, String zone) {
    final list = (json['prayerTime'] as List)
        .map((item) => PrayerDay.fromJson(item))
        .toList();
    // Extract month/year from first day's date (e.g., "01-Mei-2026")
    final monthYear = _parseMonthYear(list.isNotEmpty ? list.first.date : '');
    return MonthlyPrayerData(
      zone: zone,
      serverTime: json['serverTime'] ?? '',
      days: list,
      month: monthYear['month'] ?? DateTime.now().month,
      year: monthYear['year'] ?? DateTime.now().year,
    );
  }

  static Map<String, int> _parseMonthYear(String dateStr) {
    try {
      final parts = dateStr.split('-');
      if (parts.length != 3) return {};
      final monthAbbr = parts[1];
      final year = int.parse(parts[2]);
      const monthMap = {
        'Jan': 1, 'Feb': 2, 'Mar': 3, 'Apr': 4, 'May': 5, 'Jun': 6,
        'Jul': 7, 'Aug': 8, 'Sep': 9, 'Oct': 10, 'Nov': 11, 'Dec': 12
      };
      final month = monthMap[monthAbbr];
      if (month == null) return {};
      return {'month': month, 'year': year};
    } catch (e) {
      return {};
    }
  }
}