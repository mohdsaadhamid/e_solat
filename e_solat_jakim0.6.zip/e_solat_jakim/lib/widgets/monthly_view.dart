import 'package:flutter/material.dart';
import '../models/prayer_data.dart';

class MonthlyView extends StatelessWidget {
  final MonthlyPrayerData data;

  const MonthlyView({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Jadual Bulanan – Zon ${data.zone}',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        Expanded(
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: DataTable(
                columnSpacing: 8,
                headingRowColor: MaterialStateColor.resolveWith((states) => Colors.green[700]!),
                headingTextStyle: const TextStyle(color: Colors.white),
                columns: const [
                  DataColumn(label: Text('Tarikh')),
                  DataColumn(label: Text('Hari')),
                  DataColumn(label: Text('Imsak')),
                  DataColumn(label: Text('Subuh')),
                  DataColumn(label: Text('Syuruk')),
                  DataColumn(label: Text('Zohor')),
                  DataColumn(label: Text('Asar')),
                  DataColumn(label: Text('Maghrib')),
                  DataColumn(label: Text('Isyak')),
                ],
                rows: data.days.map((day) {
                  return DataRow(cells: [
                    DataCell(Text(day.date)),
                    DataCell(Text(day.day)),
                    DataCell(Text(day.imsak.replaceAll(RegExp(r'.{3}$'), ''))),
                    DataCell(Text(day.fajr.replaceAll(RegExp(r'.{3}$'), ''))),
                    DataCell(Text(day.syuruk.replaceAll(RegExp(r'.{3}$'), ''))),
                    DataCell(Text(day.dhuhr.replaceAll(RegExp(r'.{3}$'), ''))),
                    DataCell(Text(day.asr.replaceAll(RegExp(r'.{3}$'), ''))),
                    DataCell(Text(day.maghrib.replaceAll(RegExp(r'.{3}$'), ''))),
                    DataCell(Text(day.isha.replaceAll(RegExp(r'.{3}$'), ''))),
                  ]);
                }).toList(),
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Text(
            'Data disimpan pada: ${data.serverTime}',
            style: TextStyle(fontSize: 12, color: Colors.grey[600]),
          ),
        ),
      ],
    );
  }
}