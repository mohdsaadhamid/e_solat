import 'package:flutter/material.dart';
import '../services/zone_service.dart';

class ZoneDropdown extends StatelessWidget {
  final String selectedZone;
  final ValueChanged<String?> onChanged;

  const ZoneDropdown({super.key, required this.selectedZone, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<String>(
      isExpanded: true, // Key property to handle width and wrapping
      initialValue: selectedZone,
      decoration: const InputDecoration(
        labelText: 'Pilih Zon',
        border: OutlineInputBorder(),
      ),
      items: ZoneService.zoneCodes.map((code) {
        final displayName = ZoneService.zoneDisplayNames[code] ?? code;
        return DropdownMenuItem<String>(
          value: code,
          child: Text(
            displayName,
            softWrap: true,       // Allows text to wrap to next line
            overflow: TextOverflow.ellipsis, // Truncates if still too long
          ),
        );
      }).toList(),
      onChanged: onChanged,
    );
  }
}